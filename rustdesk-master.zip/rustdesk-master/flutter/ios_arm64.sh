#!/usr/bin/env bash
cargo build --release --target aarch64-apple-ios
