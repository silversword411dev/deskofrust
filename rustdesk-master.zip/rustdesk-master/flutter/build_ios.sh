#!/usr/bin/env bash
flutter build ipa --release --obfuscate --split-debug-info=./split-debug-info
