pub mod ffi;
use std::sync::RwLock;

pub use ffi::*;

use lazy_static::lazy_static;
